$(".accordion").accordion({
  active: false,
  collapsible: true,
  heightStyle: "fill",
  icons: false
});
