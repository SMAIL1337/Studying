new Choices(document.querySelector('#galleryFilterSelect'), {
  placeholder: false,
  itemSelectText: '',
  shouldSort: false,
  shouldSortItems: false,
  searchEnabled: false
});
