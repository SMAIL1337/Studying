var popup = document.getElementById("popup-bg");

function popupToggle() {
	popup.classList.toggle('hide');
}
